#include "Triangle.hpp"

double distance(const Point &p1, const Point &p2) {
    return sqrt(pow(p2.x - p1.x, 2) + pow(p2.y - p1.y, 2));
}

double vectorProduct(const Point &A, const Point &B, const Point &C) {
    return (B.x - A.x) * (C.y - A.y) - (B.y - A.y) * (C.x - A.x);
}

double Triangle::area() const {
    return 0.5 * fabs(vectorProduct(A, B, C));
}

bool Triangle::isDegenerate() const {
    return area() < 1e-9;
}

bool Triangle::contains(const Point &P) const {
    double d1 = vectorProduct(A, B, P);
    double d2 = vectorProduct(B, C, P);
    double d3 = vectorProduct(C, A, P);

    bool hasNeg = (d1 < 0) || (d2 < 0) || (d3 < 0);
    bool hasPos = (d1 > 0) || (d2 > 0) || (d3 > 0);

    // Точка всередині трикутника або на його межі
    return !(hasNeg && hasPos);
}
