#include "Triangle.hpp"

using namespace std;

int main() {
    Triangle t;
    cout << "Введіть координати трикутника (Ax Ay Bx By Cx Cy): ";
    cin >> t.A.x >> t.A.y >> t.B.x >> t.B.y >> t.C.x >> t.C.y;

    if (t.isDegenerate()) {
        cout << "Це вироджений трикутник (його площа дорівнює нулю)." << endl;
        return 1;
    }

    int n;
    cout << "Введіть кількість точок: ";
    cin >> n;

    for (int i = 0; i < n; ++i) {
        Point p;
        cout << "Введіть координати точки (x y): ";
        cin >> p.x >> p.y;

        if (t.contains(p)) {
            cout << "Точка (" << p.x << ", " << p.y << ") належить трикутнику або його межі." << endl;
        } else {
            cout << "Точка (" << p.x << ", " << p.y << ") не належить трикутнику." << endl;
        }
    }

    return 0;
}
